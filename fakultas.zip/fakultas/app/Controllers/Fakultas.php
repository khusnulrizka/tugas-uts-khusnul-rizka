<?php

namespace App\Controllers;

use App\Models\FakultasModel;

class Fakultas extends BaseController
{
    protected $fakultas;

    function __construct()
    {
        $this->fakultas = new FakultasModel();
    }

    public function index()
    {
        $data['fakultas'] = $this->fakultas->findAll();
        return view('fakultas/index', $data);
    }

    public function create()
    {
        return view('fakultas/create');
    }

    public function store()
    {
        if (!$this->validate([
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'dosen' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'mahasiswa' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],



        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }

        $this->fakultas->insert([
            'nama' => $this->request->getVar('nama'),
            'dosen' => $this->request->getVar('dosen'),
            'mahasiswa' => $this->request->getVar('mahasiswa')
        ]);
        session()->setFlashdata('message', 'Tambah Fakultas Berhasil');
        return redirect()->to('/fakultas');
    }

    function edit($id)
    {
        $dataFakultas = $this->fakultas->find($id);
        if (empty($dataFakultas)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data Fakultas Tidak ditemukan !');
        }
        $data['fakultas'] = $dataFakultas;
        return view('fakultas/edit', $data);
    }

    public function update($id)
    {
        if (!$this->validate([
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'dosen' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'mahasiswa' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],



        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }

        $this->fakultas->update($id, [
            'nama' => $this->request->getVar('nama'),
            'dosen' => $this->request->getVar('dosen'),
            'mahasiswa' => $this->request->getVar('mahasiswa')
        ]);
        session()->setFlashdata('message', 'Update Fakultas Berhasil');
        return redirect()->to('/fakultas');
    }

    function delete($id)
    {
        $dataFakultas = $this->fakultas->find($id);
        if (empty($dataFakultas)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data Fakultas Tidak ditemukan !');
        }
        $this->fakultas->delete($id);
        session()->setFlashdata('message', 'Delete Data Fakultas Berhasil');
        return redirect()->to('/fakultas');
    }
}
