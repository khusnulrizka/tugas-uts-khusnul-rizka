<?= $this->extend('welcome_message'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Update Data Fakultas</h3>
        </div>
        <div class="card-body">
            <?php if (!empty(session()->getFlashdata('error'))) : ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h4>Periksa Entrian Form</h4>
                    </hr />
                    <?php echo session()->getFlashdata('error'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form method="post" action="<?= base_url('fakultas/update/' . $fakultas->id) ?>">
                <?= csrf_field(); ?>

                <div class=" form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" value="<?= $fakultas->nama; ?>">
                </div>

                <div class=" form-group">
                    <label for="dosen">Dosen Penanggung Jawab</label>
                    <input type="text" class="form-control" id="dosen" name="dosen" value="<?= $fakultas->dosen; ?>">
                </div>

                <div class=" form-group">
                    <label for="mahasiswa">Total Mahasiswa</label>
                    <input type="text" class="form-control" id="mahasiswa" name="mahasiswa" value="<?= $fakultas->mahasiswa; ?>">
                </div>

                <div class="form-group">
                    <input type="submit" value="Update" class="btn btn-info" />
                </div>

            </form>
        </div>
    </div>
</div>
<?= $this->endSection('content'); ?>