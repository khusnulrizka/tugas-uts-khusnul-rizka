<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

use CodeIgniter\I18n\Time;

class FakultasSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nama'          =>  'Pendidikan Matematika',
                'dosen' =>  'Agus Widodo S.pd',
                'mahasiswa'       =>  '135',
                'created_at' => Time::now(),
                'updated_at' => Time::now()
            ]
        ];
        $this->db->table('fakultas')->insertBatch($data);
    }
}
